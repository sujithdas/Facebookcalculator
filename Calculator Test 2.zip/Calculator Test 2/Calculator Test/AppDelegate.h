//
//  AppDelegate.h
//  Calculator Test
//
//  Created by sujith das on 11/07/13.
//  Copyright (c) 2013 Sujith das. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
