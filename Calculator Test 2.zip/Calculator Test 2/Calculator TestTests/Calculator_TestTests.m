//
//  Calculator_TestTests.m
//  Calculator TestTests
//
//  Created by sujith das on 11/07/13.
//  Copyright (c) 2013 Sujith das. All rights reserved.
//

#import "Calculator_TestTests.h"

@implementation Calculator_TestTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Calculator TestTests");
}

@end
